import eel
import os

eel.init('web')

@eel.expose
def calculate_bmi(weight, height, system):
    try:
        weight = float(weight)
        height = float(height)

        if system == "metric":
            bmi = weight / (height / 100) ** 2
        elif system == "imperial":
            bmi = 703 * weight / (height ** 2)
        else:
            return "Invalid system"
        
        return round(bmi, 2)
    except:
        return "Invalid input"

eel.start('index.html', size=(500, 600))