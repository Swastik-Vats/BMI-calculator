async function calculateBMI() {
  const weight = document.getElementById("weight").value;
  const height = document.getElementById("height").value;
  const system = document.querySelector('input[name="system"]:checked').value;

  const bmi = await eel.calculate_bmi(weight, height, system)();
  document.getElementById("result").innerText = `Your BMI is: ${bmi}`;

  if (!isNaN(bmi)) {
    animateProgress(bmi);
  }
}

function animateProgress(bmi) {
  const progressBar = document.getElementById("progressBar");
  const percentage = Math.min((bmi / 40) * 100, 100);
  progressBar.style.width = percentage + "%";

  if (bmi < 18.5) {
    progressBar.style.backgroundColor = "#ffc107"; // yellow
  } else if (bmi < 25) {
    progressBar.style.backgroundColor = "#28a745"; // green
  } else if (bmi < 30) {
    progressBar.style.backgroundColor = "#fd7e14"; // orange
  } else {
    progressBar.style.backgroundColor = "#dc3545"; // red
  }
}